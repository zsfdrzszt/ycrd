<template>
	<view class="contactmain">
		<view class="status_bar" ></view>
		<view>
			
		</view>
		页面三
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
